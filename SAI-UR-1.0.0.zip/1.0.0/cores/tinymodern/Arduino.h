#ifndef Arduino_h
#define Arduino_h

#define ATTINY_CORE 1

#include <WProgram.h>

#endif
